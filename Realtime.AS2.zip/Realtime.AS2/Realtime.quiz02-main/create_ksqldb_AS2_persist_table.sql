CREATE STREAM quiz02_persist
with (
    KAFKA_TOPIC = 'quiz02_persist',
    VALUE_FORMAT = 'AVRO',
    PARTITIONS = 2
) as SELECT index,breakfast,coffee,calories_day,drink,eating_changes_coded,exercise,fries,soup,nutritional_check,employment,fav_food,income,sports,
veggies_day,indian_food,Italian_food,persian_food,thai_food,vitamins,self_perception_weight,weight
FROM quiz02_raw 
where calories_day >= 1.0
EMIT CHANGES;